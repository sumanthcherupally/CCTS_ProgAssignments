Compile instructions
	Compile with c++11 or higher version
	Use 
	g++ -std=c++11 -pthread BOCC-CTA-EE17BTECH11041.cpp -o bocc-cta
	g++ -std=c++11 -pthread FOCC-CTA-EE17BTECH11041.cpp -o focc-cta
	g++ -std=c++11 -pthread FOCC-OTA-EE17BTECH11041.cpp -o focc-ota
