Compile instructions
	Compile with c++11 or higher version
	Use 
	g++ -std=c++11 -pthread BTO-EE17BTECH11041.cpp -o bto
	g++ -std=c++11 -pthread MVTO-EE17BTECH11041.cpp -o mvto
