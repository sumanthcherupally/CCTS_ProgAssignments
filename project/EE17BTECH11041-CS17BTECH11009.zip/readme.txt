Input file - inp-params.txt cointains four space seperated parameters
numTrans, size of shared map, size of ownership array, lambda of exponential dist
Eg - 100 100 50 100.0

Compile using - g++ -std=c++11 -pthread ConcurrentMap.cpp -o concmap

